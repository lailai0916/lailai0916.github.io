#include <bits/stdc++.h>
using namespace std;

int main()
{
    freopen("B.in","r",stdin);
    freopen("B.out","w",stdout);
    
    return 0;
}