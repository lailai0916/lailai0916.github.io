#include <bits/stdc++.h>
using namespace std;

int main()
{
    freopen("A.in","r",stdin);
    freopen("A.out","w",stdout);
    
    return 0;
}