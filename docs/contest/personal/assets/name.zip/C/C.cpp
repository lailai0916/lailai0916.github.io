#include <bits/stdc++.h>
using namespace std;

int main()
{
    freopen("C.in","r",stdin);
    freopen("C.out","w",stdout);
    
    return 0;
}