#include <bits/stdc++.h>
using namespace std;

int main()
{
    freopen("D.in","r",stdin);
    freopen("D.out","w",stdout);
    
    return 0;
}